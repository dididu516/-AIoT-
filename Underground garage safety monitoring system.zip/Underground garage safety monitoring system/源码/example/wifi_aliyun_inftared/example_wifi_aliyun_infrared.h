#ifndef __EXAMPLE__ALYUN__H__
#define __EXAMPLE__ALYUN__H__
#include "stdint.h"
void example_wifi_aliyun();
void temp_task();
void aliyun_topic_sub();
int property_post_create_packet_light_switch(char *buf,uint8_t light_switch);

void example_wifi_aliyun_light_rev_task();
#endif
