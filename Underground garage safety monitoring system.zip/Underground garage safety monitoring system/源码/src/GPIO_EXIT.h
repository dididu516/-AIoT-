#ifndef __GPIO_EXTI_H
#define __GPIO_EXTI_H

#include <stdint.h>

void GPIO_EXTI_Init(void);

#endif /* __GPIO_EXTI_H */


