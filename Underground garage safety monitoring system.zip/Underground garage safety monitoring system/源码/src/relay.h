#ifndef __RELAY_H
#define __RELAY_H 

#include "sys.h"

void relay_init(void);
void relay_disconnection(void);
void relay_connection(void);


#endif
