
#ifndef __POWER_H
#define __POWER_H
int power_init();
int power_read();
void display_battery_voltage();

#endif