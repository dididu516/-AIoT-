#include "cmsis_os2.h"
#include "LED.h"
#include "usart.h"
#include "HTS221.h"
#include "stdio.h"
#include "string.h"
#include "Timer.h"

osThreadId_t tid_Thread1, tid_Thread2, tid_Thread3, tid_Thread4;
 
void Thread1 (void *argument) 
{
	while (1) 
	{
		LED_On(0);
		osDelay(500);
		LED_Off(0);
		osDelay(500);
	}
}
void Thread2 (void *argument) 
{
	while (1) 
	{
		LED_On(1);
		osDelay(200);
		LED_Off(1);
		osDelay(400);
	}
}
void Thread3 (void *argument) 
{
	float hr,temp;
	uint8_t str[50];
	USART_2_Initialization();
	HTS221_Init();
	while (1) 
	{
		temp = HTS221_Get_Temperature();
		hr = HTS_221_Get_Humidity();
		sprintf((char*)str,"\nTemperature is %.1f��\nHumidity is %.1f%%hr\n",temp,hr);
		USART_2_Send(str, strlen((char*)str));
		osDelay(1000);
	}
}

void Thread4 (void *argument) 
{
	int dir=5,PWMval=0;
	TIM3_PWM_Init();//�õ��ǻƵ�
	HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_4);
	while (1)
	{
		osDelay(20);
		PWMval = PWMval + dir;
		if(PWMval%500==0)
		{
			dir = -dir;					//�����޸�
			osDelay(100);
		}
		TIM_SetTIM3Compare4(PWMval);	//�޸�ռ�ձ�
	}
}

void app_main_2task (void *argument) 
{
	tid_Thread1 = osThreadNew (Thread1, NULL, NULL);
	tid_Thread2 = osThreadNew (Thread2, NULL, NULL);
//	tid_Thread3 = osThreadNew (Thread3, NULL, NULL);
//	tid_Thread4 = osThreadNew (Thread4, NULL, NULL);
}
