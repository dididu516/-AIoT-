#include "Aliyun.h"
#include "usart.h"
#include "string.h"
#include "drv_serial.h"
#include "bsp_wifi.h"
#include "mqtt_init.h"
#include "sign_api.h"
#include "transport.h"
#include "MQTTPacket.h"
#include "example_wifi_aliyun_infrared.h"
#include "stdio.h"
#include "adc.h"

void Aliyun_connect(void *argument)
{
//��ʼ��
  MX_USART2_UART_Init();
  MX_TIM6_Init();
  MX_USART3_UART_Init();
	MX_ADC1_Init();

	MX_TIM6_Init();
	printf("Runing....\r\n");
	drv_serial_init();
	example_wifi_aliyun();
}
