#ifndef __SENSOR_CONFIG__
#define __SENSOR_CONFIG__

//#define SENSOR_DHT11_ENABLED  

#define SENSOR_DHT11_ENABLED  

#define SENSOR_BEEP_ENABLED




#endif 