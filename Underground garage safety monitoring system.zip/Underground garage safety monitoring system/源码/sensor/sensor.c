#include "sensor.h"
#include "sensor_config.h"
#include "adc.h"
#include "dht11/dht11.h"

uint16_t ADC_ConvertedValueSmoke=0;



#ifdef SENSOR_BEEP_ENABLED

uint8_t sensor_beep_init()
{
	 GPIO_InitTypeDef GPIO_InitStruct = {0}; 
	__HAL_RCC_GPIOB_CLK_ENABLE();
	 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_RESET);
	  GPIO_InitStruct.Pin = GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

}

int sensor_beep_write(uint8_t state)
{
	if(state)
	{
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_SET);
	}else{
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_RESET);
	}
}
#endif


uint8_t sensor_smoke_init()
{
	return 0;
}

uint16_t sensor_smoke_read()//��ȡ��Ӧ��ģ���źž���ADC�������ֵ���������� uint16_t ���ͷ���
{
	  if (HAL_ADC_Start(&hadc1) != HAL_OK) {
        return 0;
    }

    if (HAL_ADC_PollForConversion(&hadc1, HAL_MAX_DELAY) == HAL_OK) {
        uint32_t adcValue = HAL_ADC_GetValue(&hadc1);
        HAL_ADC_Stop(&hadc1); 
        return (uint16_t)adcValue;
    } else {
        HAL_ADC_Stop(&hadc1); 
        return 0;
    }
		
}

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc)
{
	  if (hadc->Instance == ADC1)
    {
        ADC_ConvertedValueSmoke = HAL_ADC_GetValue(hadc);
   
    }
}


uint8_t sensor_dht11_read(uint8_t *temp,uint8_t *humi)
{
	return DHT11_Read_Data(temp,humi);
}
uint8_t sensor_dht11_init()
{
	return DHT11_Init();
}
 

