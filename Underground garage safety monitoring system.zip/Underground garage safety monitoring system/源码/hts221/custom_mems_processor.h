#ifndef __custom_mems_processor_H
#define __custom_mems_processor_H
#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "custom_bus.h"
#include "hts221.h"

   
int32_t Sensor_Init(void);
float GetTemperatureValue(void);
float GetHumValue(void);


#ifdef __cplusplus
}
#endif

#endif
