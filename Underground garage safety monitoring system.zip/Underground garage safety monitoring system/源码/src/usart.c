/**
  ******************************************************************************
  * File Name          : USART.c
  * Description        : This file provides code for the configuration
  *                      of the USART instances.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "usart.h"
#include "Aliyun.h"
/* USER CODE BEGIN 0 */
int fputc(int ch, FILE *f)
{
  HAL_UART_Transmit(&huart2, (uint8_t *)&ch, 1, 0xffff);
  return ch;
}
/* USER CODE END 0 */
#if EN_USART1_RX
UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;
UART_HandleTypeDef huart3;
uint16_t	UART3_RX_STA=0;
uint16_t	read_buf_len=0;
uint8_t UART3_RX_BUF[400];

uint8_t USART1_RX_BUF[USART_REC_LEN];     //���ջ���,���USART_REC_LEN���ֽ�.
uint8_t USART2_RX_BUF[USART_REC_LEN];
uint8_t rec[93];							//���ڽ��յ����������
uint8_t i=0;

float voltage;								//��ѹֵ
uint32_t voltage1;
float current;								//����ֵ
uint32_t current1;
float activePower;							//�й�����
uint32_t activePower1;
float factor;								//��������
uint32_t factor1;

uint16_t USART1_RX_STA = 0;     //����״̬���
uint16_t USART2_RX_STA = 0; 
/* USART1 init function */

void MX_USART1_UART_Init(void)
{

  huart1.Instance = USART1;
  huart1.Init.BaudRate = 9600;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
   __HAL_UART_ENABLE_IT(&huart1, UART_IT_RXNE); //���������ж�
    HAL_NVIC_EnableIRQ(USART1_IRQn);					//ʹ��USART1�ж�ͨ��
    HAL_NVIC_SetPriority(USART1_IRQn, 3, 3);				//��ռ���ȼ�3�������ȼ�3

}
/* USART2 init function */

void MX_USART2_UART_Init(void)
{

  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;

  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
      __HAL_UART_ENABLE_IT(&huart2, UART_IT_RXNE); //���������ж�
    HAL_NVIC_EnableIRQ(USART2_IRQn);					//ʹ��USART2�ж�ͨ��
    HAL_NVIC_SetPriority(USART2_IRQn, 3, 3);				//��ռ���ȼ�3�������ȼ�3


}
/* USART3 init function */

void MX_USART3_UART_Init(void)
{

  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  huart3.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart3.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }

}

void HAL_UART_MspInit(UART_HandleTypeDef* uartHandle)
{

  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(uartHandle->Instance==USART1)
  {
  /* USER CODE BEGIN USART1_MspInit 0 */

  /* USER CODE END USART1_MspInit 0 */
    /* USART1 clock enable */
    __HAL_RCC_USART1_CLK_ENABLE();

    __HAL_RCC_GPIOA_CLK_ENABLE();
    /**USART1 GPIO Configuration
    PA9     ------> USART1_TX
    PA10     ------> USART1_RX
    */
    GPIO_InitStruct.Pin = GPIO_PIN_9|GPIO_PIN_10;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FAST;
    GPIO_InitStruct.Alternate = GPIO_AF7_USART1;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* USART1 interrupt Init */
    
  /* USER CODE BEGIN USART1_MspInit 1 */

  /* USER CODE END USART1_MspInit 1 */
  }
  else if(uartHandle->Instance==USART2)
  {
  /* USER CODE BEGIN USART2_MspInit 0 */

  /* USER CODE END USART2_MspInit 0 */
    /* USART2 clock enable */
    __HAL_RCC_USART2_CLK_ENABLE();

    __HAL_RCC_GPIOA_CLK_ENABLE();
    /**USART2 GPIO Configuration
    PA2     ------> USART2_TX
    PA3     ------> USART2_RX
    */
    GPIO_InitStruct.Pin = GPIO_PIN_2|GPIO_PIN_3;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FAST;
    GPIO_InitStruct.Alternate = GPIO_AF7_USART2;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* USER CODE BEGIN USART2_MspInit 1 */
	
  /* USER CODE END USART2_MspInit 1 */
  }
  else if(uartHandle->Instance==USART3)
  {
  /* USER CODE BEGIN USART3_MspInit 0 */

  /* USER CODE END USART3_MspInit 0 */
    /* USART3 clock enable */
    __HAL_RCC_USART3_CLK_ENABLE();

    __HAL_RCC_GPIOC_CLK_ENABLE();
    /**USART3 GPIO Configuration
    PC4     ------> USART3_TX
    PC5     ------> USART3_RX
    */
    GPIO_InitStruct.Pin = GPIO_PIN_4|GPIO_PIN_5;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF7_USART3;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    /* USART3 interrupt Init */
    HAL_NVIC_SetPriority(USART3_IRQn, 3, 3);
    HAL_NVIC_EnableIRQ(USART3_IRQn);
  /* USER CODE BEGIN USART3_MspInit 1 */

  /* USER CODE END USART3_MspInit 1 */
  }
}

void HAL_UART_MspDeInit(UART_HandleTypeDef* uartHandle)
{

  if(uartHandle->Instance==USART1)
  {
  /* USER CODE BEGIN USART1_MspDeInit 0 */

  /* USER CODE END USART1_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_USART1_CLK_DISABLE();

    /**USART1 GPIO Configuration
    PA9     ------> USART1_TX
    PA10     ------> USART1_RX
    */
    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_9|GPIO_PIN_10);

    /* USART1 interrupt Deinit */
    HAL_NVIC_DisableIRQ(USART1_IRQn);
  /* USER CODE BEGIN USART1_MspDeInit 1 */

  /* USER CODE END USART1_MspDeInit 1 */
  }
  else if(uartHandle->Instance==USART2)
  {
  /* USER CODE BEGIN USART2_MspDeInit 0 */

  /* USER CODE END USART2_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_USART2_CLK_DISABLE();

    /**USART2 GPIO Configuration
    PA2     ------> USART2_TX
    PA3     ------> USART2_RX
    */
    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_2|GPIO_PIN_3);

  /* USER CODE BEGIN USART2_MspDeInit 1 */

  /* USER CODE END USART2_MspDeInit 1 */
  }
  else if(uartHandle->Instance==USART3)
  {
  /* USER CODE BEGIN USART3_MspDeInit 0 */

  /* USER CODE END USART3_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_USART3_CLK_DISABLE();

    /**USART3 GPIO Configuration
    PC4     ------> USART3_TX
    PC5     ------> USART3_RX
    */
    HAL_GPIO_DeInit(GPIOC, GPIO_PIN_4|GPIO_PIN_5);

    /* USART3 interrupt Deinit */
    HAL_NVIC_DisableIRQ(USART3_IRQn);
  /* USER CODE BEGIN USART3_MspDeInit 1 */

  /* USER CODE END USART3_MspDeInit 1 */
  }
}
int rxConut=0;
void USART3_IRQHandler(void)
{
	
	
//	if(__HAL_UART_GET_FLAG(&huart3,UART_FLAG_IDLE) != RESET)
//	{
//		__HAL_UART_CLEAR_IT(&huart3, UART_CLEAR_IDLEF);
//		rxConut = 1024 - huart3.RxXferCount;
//		HAL_UART_AbortReceive_IT(&huart3);
//		HAL_UART_Transmit(&huart1, UART3_Rx_Buf, rxConut, 1000);
//		HAL_UART_Receive_IT(&huart3,UART3_Rx_Buf,1024);
//	}
	HAL_UART_IRQHandler(&huart3);
}
  
/* USER CODE BEGIN 1 */

/* USER CODE END 1 */
void USART2_IRQHandler(void)
{
    uint8_t Res;

    if((__HAL_UART_GET_FLAG(&huart2, UART_FLAG_RXNE) != RESET)) //�����ж�(���յ������ݱ�����0x0d 0x0a��β)
    {
        HAL_UART_Receive(&huart2, &Res, 1, 1000);

        if((USART2_RX_STA & 0x8000) == 0) //����δ���
        {
            if(USART2_RX_STA & 0x4000) //���յ���0x0d
            {
                if(Res != 0x0a)USART2_RX_STA = 0; //���մ���,���¿�ʼ

                else USART2_RX_STA |= 0x8000;	//���������
            }
            else //��û�յ�0X0D
            {
                if(Res == 0x0d)USART2_RX_STA |= 0x4000;
                else
                {
                    USART2_RX_BUF[USART2_RX_STA & 0X3FFF] = Res ;
                    USART2_RX_STA++;

                    if(USART2_RX_STA > (USART_REC_LEN - 1))USART2_RX_STA = 0; //�������ݴ���,���¿�ʼ����
                }
            }
        }
    }
    HAL_UART_IRQHandler(&huart2);
}

void USART1_IRQHandler(void)
{
    uint8_t Res;
	

    if((__HAL_UART_GET_FLAG(&huart1, UART_FLAG_RXNE) != RESET)) //�����ж�(���յ������ݱ�����0x0d 0x0a��β)
    {
		
        HAL_UART_Receive(&huart1, &Res, 1, 1000);
		
		rec[i++]=Res;
//		HAL_UART_Transmit(&huart2, &rec[i-1],1, 1000);	//����2���ͽ��յ�������
		if(i==93) 												//�����������з����źŵ�ʱ��������
		{
			i=0;
			//��ѹֵ
			voltage1=(((uint32_t)rec[3]) << 24) | (((uint32_t)rec[4]) << 16) | (((uint32_t)rec[5] )<< 8) | ((uint32_t)rec[6]);
			voltage=*(float*)&voltage1;
			printf("\r\n");
			printf("%.2f",voltage);
			printf("\r\n");
			//����ֵ
			current1=(((uint32_t)rec[19]) << 24) | (((uint32_t)rec[20]) << 16) | (((uint32_t)rec[21] )<< 8) | ((uint32_t)rec[22]);
			current=*(float*)&current1;
			printf("%.2f",current);
			printf("\r\n");
			//�й�����
			activePower1=(((uint32_t)rec[39]) << 24) | (((uint32_t)rec[40]) << 16) | (((uint32_t)rec[41] )<< 8) | ((uint32_t)rec[42]);
			activePower=*(float*)&activePower1;
			printf("%.2f",activePower);
			printf("\r\n");
			//��������
			factor1=(((uint32_t)rec[87]) << 24) | (((uint32_t)rec[88]) << 16) | (((uint32_t)rec[89] )<< 8) | ((uint32_t)rec[90]);
			factor=*(float*)&factor1;
			printf("%.2f",factor);
			printf("\r\n");

		}
//        while(__HAL_UART_GET_FLAG(&huart2, UART_FLAG_TC) != SET);		//�ȴ����ͽ���
//		__HAL_UART_CLEAR_FLAG(&huart2, UART_FLAG_TC);
//		
	}
}
#endif

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
