#ifndef __Aliyun_H
#define __Aliyun_H

#include <stdint.h>
#include "stm32l4xx_hal.h"
extern	uint8_t UART3_Rx_Buf[1024];
void Aliyun_connect(void *argument);
#endif  /* __LED_H */
