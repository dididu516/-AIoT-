#ifndef __SENSOR_H__
#define __SENSOR_H__

#include "sys.h"
#include "stm32l4xx_hal.h"
#include "sensor_config.h"

uint8_t sensor_smoke_init();
uint16_t sensor_smoke_read();

//uint8_t sensor_fire_init();
//uint16_t sensor_fire_read();

uint8_t sensor_beep_init();
int sensor_beep_write(uint8_t state);
int sensor_led_write(uint8_t state);
void sensor_jdq_init();

uint8_t sensor_led_init();
uint8_t sensor_dht11_read(uint8_t *temp,uint8_t *humi);

uint8_t sensor_dht11_init();




#endif